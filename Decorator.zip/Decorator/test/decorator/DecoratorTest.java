/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decorator;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class DecoratorTest {
    
    public DecoratorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class Decorator.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Decorator.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of decoratorXML method, of class Decorator.
     * Test para Append
     */
    @Test
    public void test1_DecoratorXML() {
        System.out.println("decoratorXML- Test01");
        String fSource = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\01-append\\source.xml";
        String fDecorator = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\01-append\\decorator.xml";
        String Respuesta = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\01-append\\SalidaArchivo.xml";
        Decorator.decoratorXML(fSource, fDecorator, Respuesta);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    /**
     * Test of decoratorXML method, of class Decorator.
     * Test para Insert
     */
    @Test
    public void test2_DecoratorXML() {
        System.out.println("decoratorXML - Test02");
        String fSource = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\02-insert\\source.xml";
        String fDecorator = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\02-insert\\decorator.xml";
        String Respuesta = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\02-insert\\SalidaArchivo.xml";
        Decorator.decoratorXML(fSource, fDecorator, Respuesta);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    
    @Test
    public void test3_DecoratorXML() {
        System.out.println("decoratorXML - Test03");
        String fSource = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\03-replace\\source.xml";
        String fDecorator = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\03-replace\\decorator.xml";
        String Respuesta = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\03-replace\\SalidaArchivo.xml";
        Decorator.decoratorXML(fSource, fDecorator, Respuesta);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void test4_DecoratorXML() {
        System.out.println("decoratorXML - Test04");
        String fSource = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\04-all\\source.xml";
        String fDecorator = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\04-all\\decorator.xml";
        String Respuesta = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\04-all\\SalidaArchivo.xml";
        Decorator.decoratorXML(fSource, fDecorator, Respuesta);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
   
    @Test
    public void test5_DecoratorXML() {
        System.out.println("decoratorXML - Test05");
        String fSource = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\05-multiappend\\source.xml";
        String fDecorator = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\05-multiappend\\decorator.xml";
        String Respuesta = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\05-multiappend\\SalidaArchivo.xml";
        Decorator.decoratorXML(fSource, fDecorator, Respuesta);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void test6_DecoratorXML() {
        System.out.println("decoratorXML - Test06");
        String fSource = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\06-multinode\\source.xml";
        String fDecorator = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\06-multinode\\decorator.xml";
        String Respuesta = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\06-multinode\\SalidaArchivo.xml";
        Decorator.decoratorXML(fSource, fDecorator, Respuesta);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void test7_DecoratorXML() {
        System.out.println("decoratorXML - Test07");
        String fSource = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\07-multiref\\source.xml";
        String fDecorator = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\07-multiref\\decorator.xml";
        String Respuesta = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\07-multiref\\SalidaArchivo.xml";
        Decorator.decoratorXML(fSource, fDecorator, Respuesta);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void test11_DecoratorXML() {
        System.out.println("decoratorXML - Test11");
        String fSource = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\11-addstyle\\Intro.xhtml";
        String fDecorator = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\11-addstyle\\addstyle.xml";
        String Respuesta = "C:\\Users\\Administrator\\Documents\\NetBeansProjects\\Decorator\\tests\\11-addstyle\\SalidaArchivo.xhtml";
        Decorator.decoratorXML(fSource, fDecorator, Respuesta);
        System.out.println("Finalizo");
        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    
}
