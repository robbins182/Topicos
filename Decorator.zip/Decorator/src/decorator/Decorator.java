/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decorator;

import java.io.FileInputStream; 
import java.io.FileNotFoundException; 
import java.io.IOException;
import java.io.File;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.TransformerException;

import javax.xml.parsers.DocumentBuilder; 
import javax.xml.parsers.DocumentBuilderFactory; 
import javax.xml.parsers.ParserConfigurationException; 
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants; 
import javax.xml.xpath.XPathExpressionException; 
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document; 
import org.w3c.dom.Element; 
import org.w3c.dom.Node; 
import org.w3c.dom.NodeList; 
import org.xml.sax.InputSource; 
import org.xml.sax.SAXException;


/**
 *
 * @author Administrator
 */
public class Decorator {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        
    }
    
    static void decoratorXML(String fSource, String fDecorator, String Respuesta){
        
         try {
            
            File fileDecorator = new File(fDecorator);
            File fileSource = new File(fSource);

            // Construimos nuestro DocumentBuilder 
            DocumentBuilder documentBuilderDec = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            // Procesamos el fichero XML y obtenemos nuestro objeto Document 
            Document doc = documentBuilderDec.parse(new InputSource(new FileInputStream(fileDecorator)));
            Document docSource = documentBuilder.parse(new InputSource(new FileInputStream(fileSource)));
            
            // Obtenemos la etiqueta raiz 
            Element elementRaiz = doc.getDocumentElement();
            //System.out.println("Nodo Elemento Raiz: "+ elementRaiz); 
         
               
            // Iteramos sobre sus hijos 
            NodeList decoradores = elementRaiz.getChildNodes(); 
            
            for(int i=0;i<decoradores.getLength();i++){ 
                Node decoratorNode = decoradores.item(i);
                //Obtener la referencia de los archivos Decoradores
                String referencia = decoratorNode.getAttributes().getNamedItem("ref").getTextContent();
               
                NodeList accionesDecorador = decoratorNode.getChildNodes();
                for(int j = 0; j < accionesDecorador.getLength(); j++)
                {
                    Node acctionDecNode = accionesDecorador.item(j);
                    String accion = acctionDecNode.getNodeName();
                    if(accion.equals("cora:append"))
                    {
                        NodeList elementsToAppend = acctionDecNode.getChildNodes();
                        for(int m = 0;m< elementsToAppend.getLength(); m++)
                        {
                            Node appendNodo = elementsToAppend.item(m);
                            //Obtener Xpath del archivo Source
                            Node sourceNodo = (Node)(XPathFactory.newInstance().newXPath().compile(referencia).evaluate(docSource, XPathConstants.NODE));
                            
                            //Adicionar nuevo elemento en archivo Source
                            Element nuevaEtiqueta = docSource.createElement(appendNodo.getNodeName());
                            nuevaEtiqueta.setTextContent(appendNodo.getTextContent());
                            sourceNodo.appendChild(nuevaEtiqueta);
                        }
                    }
                    if(accion.equals("cora:insert"))
                    {
                        NodeList elementsToInsert = acctionDecNode.getChildNodes();
                        for(int m = 0;m< elementsToInsert.getLength(); m++)
                        {
                            Node insertNodo = elementsToInsert.item(m);                           
                            Node sourceNodoAfter = (Node)(XPathFactory.newInstance().newXPath().compile(referencia).evaluate(docSource, XPathConstants.NODE));
                            Element nuevaEtiqueta = docSource.createElement(insertNodo.getNodeName());
                            nuevaEtiqueta.setTextContent(insertNodo.getTextContent());  
                            sourceNodoAfter.getParentNode().insertBefore(nuevaEtiqueta, sourceNodoAfter);
                        }
                    }
                    if(accion.equals("cora:replace"))
                    {
                        NodeList elementsToreplace = acctionDecNode.getChildNodes();
                       
                            Node insertNodo = elementsToreplace.item(0); 
                            Node sourceNodo = (Node)(XPathFactory.newInstance().newXPath().compile(referencia).evaluate(docSource, XPathConstants.NODE));
                            Element nuevaEtiqueta = docSource.createElement(insertNodo.getNodeName());
                            nuevaEtiqueta.setTextContent(insertNodo.getTextContent());  
                            sourceNodo.getParentNode().replaceChild(nuevaEtiqueta,sourceNodo);                            
                        
                    }
                }               
            } 
		// Escribir el XML de salida.
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(docSource);
		StreamResult result = new StreamResult(new File(Respuesta));
                
                transformer.transform(source, result);
 
		System.out.println("Archivo Guardado");
   
   

        }catch (FileNotFoundException e) { 
        }catch (SAXException | XPathExpressionException | ParserConfigurationException | TransformerException | IOException e) { 
        }
        
        
    }
    
    
}
